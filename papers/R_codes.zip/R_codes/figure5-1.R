install.packages("deldir")
install.packages("magic")
install.packages("geometry")
install.packages("spatstat")
install.packages("rgdal")
install.packages("tripack")

library(deldir)
library(magic)
library(geometry)
library(spatstat)
library(rgdal)
library(tripack)

# Random sample in the unit square
R <- matrix(runif(13), nc = 1)
T <- 2*pi*matrix(runif(13), nc = 1)

X <- cbind(R*cos(T),R*sin(T))

R<-sqrt((X[,1]-0)^2+(X[,2]-0)^2)

RR<-sort(R)

filled.circle <- function(x,y,r,nsteps=100,...){  
  rs <- seq(0,2*pi,len=nsteps) 
  xc <- x+r*cos(rs) 
  yc <- y+r*sin(rs) 
  polygon(xc,yc,...) 
}

plot(1, type="n",axes=F,xlab="", ylab="",xlim=c(-1,1),ylim=c(-1,1))
filled.circle(0,0,1,nsteps=1000,col='lightblue')

points(1, type="n",axes=F,xlab="", ylab="",xlim=c(-1,1),ylim=c(-1,1))
filled.circle(0,0,RR[5],nsteps=1000,col='blue')

points(X[order(R),][1:5,], col = "orange", cex = 1.2, pch = 16, xlab = "", ylab = "", xlim=c(-1,1), ylim=c(-1,1))

points(X[order(R),][6:13,], col = "blue", cex = 1.2, pch = 16, xlab = "", ylab = "", xlim=c(-1,1), ylim=c(-1,1))



