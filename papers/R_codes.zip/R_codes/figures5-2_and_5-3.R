library(magic)
library(geometry)
library(spatstat)
library(sp) 
library(rgdal)
 
lambda = 10

mm=5

R=0.5 

M=2*lambda

N1 <- 10
N2 <- 100 # was 1000 # was 50 

P1 <- matrix(0,M+1) 
V1 <- matrix(0,M+1) 

P2 <- matrix(0,M+1) 
V2 <- matrix(0,M+1) 

EXACT <- matrix(0,M+1) 

A1 <- matrix(0,N1,N2)
B1 <- matrix(0,N1) 

for (i1 in 1:N1){
for (i2 in 1:N2){
Z = rpoispp(lambda) 
X <- cbind(Z$x,Z$y);
L=(X[,1]-0.5)*(X[,1]-0.5)+(X[,2]-0.5)*(X[,2]-0.5)
D=sort(L) 
V=pi*(R*R-D)
Y=X[D<=0.5*0.5]
if (length(Y) < 2*mm) A1[i1,i2]=0 # length(X)/2
else
A1[i1,i2]=length(Y)/2-mm
}
}

for (n in 0:M){

for (i1 in 1:N1) B1[i1]=length(which(A1[i1,]==n))/N2

P1[n+1] = mean(B1)
V1[n+1] = var(B1)

print(c(n,P1[n+1],V1[n+1]))

}

for (n in 0:M){

A2 <- matrix(0,N1,N2)
B2 <- matrix(0,N1) 

for (i1 in 1:N1){
for (i2 in 1:N2){
Z = rpoispp(lambda) 
X <- cbind(Z$x,Z$y);
L=(X[,1]-0.5)*(X[,1]-0.5)+(X[,2]-0.5)*(X[,2]-0.5)
D=sort(L) 
V=pi*(R*R-D)
Y=X[D<=0.5*0.5]
if (length(Y) < 2*mm) A2[i1,i2]=0^n
else A2[i1,i2]=(lambda*V[mm])^n*exp(-lambda*V[mm])
}
}

for (i1 in 1:N1) B2[i1]=sum(A2[i1,])/N2/factorial(n)

P2[n+1] = mean(B2)
V2[n+1] = var(B2)

EXACT[n+1]=exp(-lambda*R*R*pi)*(lambda*pi*R*R)^(n+mm)/factorial(n+mm)

print(c(n,P1[n+1],V1[n+1]))
print(c(n,P2[n+1],V2[n+1]))

}

EXACT[1]=0;
for (k in 1:mm){
EXACT[1]=EXACT[1]+exp(-lambda*R*R*pi)*(lambda*pi*R*R)^k/factorial(k);
}

plot(P1,col="darkorange",xlab="n",cex=1.5,ylab="Probability p",axes=FALSE,ylim=c(0,max(EXACT,P2,P2)))
points(P2,col="blue",cex=1.5,pch=16) 
points(EXACT,col="black",cex=2.1,pch=1) 
lines(P2,col="blue",lw=4)
lines(P1,col="darkorange",lty=2, lw=4) 
lines(EXACT,col="black",lty=2, lw=4) 
points(dpois(x=0:M,lambda),col="red",lty=2, lw=4)
lines(dpois(x=0:M,lambda),col="red",lty=2, lw=4)
legend("topright",legend=c("Sampling","Averaging",expression(paste("Poisson(",lambda,")")),"Exact"),col=c("darkorange","blue","red","black"),lw=3,lty=c(2,1,2,2),cex=c(1.8))
axis(1,at=seq(1,M+1,1),labels=seq(0,M,1)) 
axis(2) 

