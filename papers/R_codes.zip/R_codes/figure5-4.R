install.packages("ggplot2")
install.packages("plyr")

library(spatstat)
library(ggplot2)
library(plyr)

lambda = 4

Z = rpoispp(lambda)

# Zx<-Z$x;Zy<-Z$y

# Random sample in the unit square
X <- matrix(runif(26), nc = 2)

Zx<-X[,1]
Zy<-X[,2]

species=array(1,length(Zx))

Y <- cbind(Zx,Zy,species);

df<-as.data.frame(Y)

find_hull <- function(df) df[chull(df$Zx, df$Zy), ]
hulls <- ddply(df, "species", find_hull)
plot <- ggplot(data = df, aes(x = Zx, y = Zy, colour=species, fill = species)) +
    geom_point(size = 3, show.legend = FALSE,colour = "red") +
    geom_point(data = hulls,size = 3, show.legend = FALSE,colour = "blue") + 
    geom_polygon(data = hulls, colour = "blue", alpha = 0.4,show.legend = FALSE,size = 1) +  
    labs(x = "", y = "") + theme_classic() + theme(
  panel.background = element_rect(fill = "lightblue",
                                colour = "lightblue",
                                size = 0.5, linetype = "solid"),
				# axis.line = element_line(size = 0.5, linetype = "solid", colour = "black"),
				panel.border = element_rect(colour = "black", fill=NA, size=1))	+ theme(legend.position="none")				+ scale_x_continuous(limits = c(0,1)) + scale_y_continuous(limits = c(0,1))

plot  + scale_fill_gradient(low = "blue", high = "pink")


