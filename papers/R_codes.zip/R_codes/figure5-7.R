install.packages("plotrix")
install.packages("DescTools")
install.packages("deldir")
install.packages("magic")
install.packages("geometry")
install.packages("spatstat")
install.packages("rgdal")
install.packages("tripack")

library("plotrix")
library(DescTools)
library(deldir)
library(magic)
library(geometry)
library(spatstat)
library(rgdal)
library(tripack)

lambda = 20

Z = rpoispp(lambda) 
X <- cbind(Z$x,Z$y);
X <- rbind(X,c(0.5,0.5));

# Random sample in the unit square
X <- matrix(runif(30), nc = 2)
X <- rbind(X,c(0.5,0.5));

c <- voronoi.mosaic(X[,1],X[,2])

xx <- ppp(.5, .5, c(0,1),c(0,1))
par(mar=c(1,1,1,1))
plot(c,main=NULL,xlab="",ylab="")
rect(xleft=par("usr")[1]*1.07, ybottom=par("usr")[3]*1.08, 
     xright=par("usr")[2]*1.0,ytop=par("usr")[4]*1.0, 
     lwd=2, border="black", xpd=TRUE)
points(X,col="purple",cex=2,pch=18)
# points(X,col="blue",cex=1.2,pch=4)
# plot(xx, add = TRUE, col = "red", cex = 3, pch = 20)
plot(xx, add = TRUE, col = "red", cex = 3, pch = 18)

cc<-cells(c) 
l<-length(cc)

mycol <- rgb(0, 0, 255, max = 255, alpha = 30, names = "blue50")
lll<-length(cc[[l]]$nodes)/2

for (i in 1:lll) 
{
r=sqrt((cc[[l]]$nodes[1,i]-0.5)^2+(cc[[l]]$nodes[2,i]-0.5)^2)
# DrawCircle(cc[[l]]$nodes[2*i+1],cc[[l]]$nodes[2*i+2],r, r.in = 0, theta.1 = 0, theta.2 = 2*pi, density = 0.5, border = "green", col = "blue", lty = par("lty"), lwd = par("lwd"), nv = 100, plot = TRUE)
draw.circle(cc[[l]]$nodes[1,i],cc[[l]]$nodes[2,i],1.02*r,nv=1000,lty=1,lwd=1.5,border="black",col=mycol) 
# circles(cc[[l]]$nodes[2*i+1],cc[[l]]$nodes[2*i+2],r)
zz <- ppp(cc[[l]]$nodes[1,i],cc[[l]]$nodes[2,i], c(0,1),c(0,1))
plot(zz, add = TRUE, col = "blue", cex = 2, pch = 20)
}

