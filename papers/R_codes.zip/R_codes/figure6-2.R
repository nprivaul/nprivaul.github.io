install.packages("deldir")
install.packages("magic")
install.packages("geometry")
install.packages("spatstat")
install.packages("gdal")
install.packages("tripack")

library(deldir)
library(magic)
library(geometry)
library(spatstat)
library(rgdal)
library(tripack)

lambda = 4

M=8

N1 <- 10 # Choose N1=10 for Figure 10 
N2 <- 50 # Choose N1=1000 for Figure 10 

P1 <- matrix(0,M+1) 
V1 <- matrix(0,M+1) 

P2 <- matrix(0,M+1) 
V2 <- matrix(0,M+1) 

A1 <- matrix(0,N1,N2)
B1 <- matrix(0,N1) 

for (i1 in 1:N1){
for (i2 in 1:N2){

Z = rpoispp(lambda);X <- cbind(Z$x,Z$y);ll<-length(X)/2

if (ll==0) {A1[i1,i2]=0} else {
if (ll==1) {X <- c(0.5,0.5)} else { 
X <- X[1:(ll-1),];X <- rbind(X,c(0.5,0.5));
}

ll<-length(X)/2

# if (ll==1) print(c("ll",ll))

if (ll<=2) {A1[i1,i2]=ll} else {
c <- voronoi.mosaic(X[,1],X[,2])
cc<-cells(c);l<-length(cc);lll=length(cc[[l]]$nodes)/2
if (lll<=2) {A1[i1,i2]=ll} else A1[i1,i2]=lll+1
}}
}}

for (n in 0:M){
for (i1 in 1:N1) B1[i1]=length(which(A1[i1,]==n))/N2
P1[n+1] = mean(B1)
V1[n+1] = var(B1)
print(c(n,P1[n+1],V1[n+1]))
}

for (n in 0:M){

A2 <- matrix(0,N1,N2)
B2 <- matrix(0,N1) 

for (i1 in 1:N1){
for (i2 in 1:N2){

Z = rpoispp(lambda);X <- cbind(Z$x,Z$y);ll<-length(X)/2

if (ll==0) {a=1} else{
if (ll==1) {X <- c(0.5,0.5)} else { 
X <- X[1:(ll-1),];X <- rbind(X,c(0.5,0.5));
}

if (ll<=2) {a=1} else {
c <- voronoi.mosaic(X[,1],X[,2]);cc<-cells(c);l<-length(cc)

lll=length(cc[[l]]$nodes)/2

if (lll<=2) {a=1} else {
xxx <- matrix(0,(length(cc[[l]]$nodes)/2)) 
yyy <- matrix(0,(length(cc[[l]]$nodes)/2)) 
rr<-c()
for (i in 1:(length(cc[[l]]$nodes)/2)) 
{
rr=c(rr,sqrt((cc[[l]]$nodes[1,i]-0.5)^2+(cc[[l]]$nodes[2,i]-0.5)^2))
xxx[i]=cc[[l]]$nodes[1,i]
yyy[i]=cc[[l]]$nodes[2,i]
}

Z <- ppp(xxx,yyy, c(min(0,xxx),max(1,xxx)), c(min(0,yyy),max(1,yyy)))
a<-area(intersect.owin(unit.square(),discs(Z,radii= rr,mask = FALSE)))

}}}

l=length(X)/2
if (l<=n) A2[i1,i2]=(-1)^(n-l)*(lambda*(1-a))^(n-l)*exp(lambda*(1-a))/factorial(n-l)
else A2[i1,i2]=0
}}

for (i1 in 1:N1) B2[i1]=sum(A2[i1,])/N2

P2[n+1] = mean(B2)
V2[n+1] = var(B2)

print(c(n,P1[n+1],V1[n+1]))
print(c(n,P2[n+1],V2[n+1]))

}

plot(P2,col="blue",xlab="n",cex=1.5,ylab="Probability p",axes=FALSE)
points(P1,col="darkorange",cex=1.5,pch=16) 
lines(P1,col="darkorange",lty=2, lw=4) 
lines(P2,col="blue",lw=4)
points(dpois(x=0:M,lambda),col="red",lty=2, lw=4)
lines(dpois(x=0:M,lambda),col="red",lty=2, lw=4) 
legend("bottom",legend=c("Sampling","Averaging",expression(paste("Poisson(",lambda,")"))),col=c("darkorange","blue","red"),lty=c(2,1,2),lwd=3,cex=1.9)
# legend("topright",legend=c("sampling","averaging",expression(paste("Poisson(",lambda,")"))),pch=c(1,1),col=c("darkorange","blue","red"))
axis(1,at=seq(1,M+1,1),labels=seq(0,M,1)) 
axis(2) 

# Error plots

plot(sqrt(V1),col="orange",xlab="n",cex=1.5,ylab="Standard deviation",axes=FALSE)
points(sqrt(V2),col="blue",cex=1.5,pch=16) 
points(sqrt(P1*(1-P1)/N2),col="green",cex=1.3,pch=16)
lines(sqrt(P1*(1-P1)/N2),lty=1,col="green",lw=4) 
lines(sqrt(V1),lty=2,col="orange",lw=4) 
lines(sqrt(V2),col="blue",lw=4) 
legend("topright",legend=c("Sampling","Averaging",expression(sqrt(p(1-p)/N))),col=c("orange","blue","green"),lty=c(2,1,1),lwd=3,cex=1.5)
axis(1,at=seq(1,M+1,1),labels=seq(0,M,1)) 
axis(2) 


