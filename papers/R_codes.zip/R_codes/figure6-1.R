install.packages("magic")
install.packages("geometry")
install.packages("spatstat")
install.packages("rgdal")

library(magic)
library(geometry)
library(spatstat)
library(rgdal)

lambda = 4

M= 10

N1 <- 10  # Choose N1=10 for Figure 9 
N2 <- 100 # Choose N2=1000 for Figure 9 

P1 <- matrix(0,M+1) 
V1 <- matrix(0,M+1) 

P2 <- matrix(0,M+1) 
V2 <- matrix(0,M+1) 

A1 <- matrix(0,N1,N2)
B1 <- matrix(0,N1) 

for (i1 in 1:N1){
for (i2 in 1:N2){
Z = rpoispp(lambda) 
X <- cbind(Z$x,Z$y);

ll<-length(X)/2

if (ll <= 2) A1[i1,i2]=ll
else
A1[i1,i2]=length(chull(X)) # length(convhulln(X, "FA")$hull)/2
}
}

for (n in 0:M){

for (i1 in 1:N1) B1[i1]=length(which(A1[i1,]==n))/N2

P1[n+1] = mean(B1)
V1[n+1] = var(B1)

print(c(n,P1[n+1],V1[n+1]))

}

for (n in 0:M){

A2 <- matrix(0,N1,N2)
B2 <- matrix(0,N1) 

for (i1 in 1:N1){
for (i2 in 1:N2){
Z = rpoispp(lambda) 
X <- cbind(Z$x,Z$y);
l=length(X)/2
if (l<=n)
if (l<=2) A2[i1,i2]=(-1)^(n-l)*0^(n-l)/factorial(n-l) else {A2[i1,i2]=(-1)^(n-l)*(lambda*convhulln(X, "FA")$vol)^(n-l)*exp(lambda*convhulln(X, "FA")$vol)/factorial(n-l)
# print(convhulln(X, "FA")$vol)
}
}
}

for (i1 in 1:N1) B2[i1]=sum(A2[i1,])/N2

P2[n+1] = mean(B2)
V2[n+1] = var(B2)

print(c(n,P1[n+1],V1[n+1]))
print(c(n,P2[n+1],V2[n+1]))

}

plot(P2,col="blue",cex=1.5,pch=16,xlab="n",ylab="Probability p",axes=FALSE)
points(P1,col="darkorange",cex=1.5) 
lines(P1,col="darkorange",lty=2, lw=4) 
lines(P2,col="blue",lw=4) 
points(dpois( x=0:M, lambda ),col="red",lty=2, lw=4)
lines(dpois( x=0:M, lambda ),col="red",lty=2, lw=4)
legend("topright",legend=c("Sampling","Averaging",expression(paste("Poisson(",lambda,")"))),col=c("darkorange","blue","red"),lty=c(2,1,2),lwd=3,cex=1.9)
# legend("topright",legend=c("sampling","averaging"),pch=c(1,1),col=c("darkorange","blue"))
axis(1,at=seq(1,M+1,1),labels=seq(0,M,1)) 
axis(2) 

# Error plots

plot(sqrt(V2),col="blue",pch=16,xlab="n",cex=1.5,ylim=c(0,max(sqrt(V2))),ylab="Standard deviation",axes=FALSE)
points(sqrt(P1*(1-P1)/N2),col="green",cex=1.3,pch=16)
lines(sqrt(P1*(1-P1)/N2),lty=1,col="green",lw=4) 
points(sqrt(V1),col="orange",cex=1.5)
lines(sqrt(V1),lty=2,col="orange",lw=4) 
lines(sqrt(V2),col="blue",lw=4) 
legend("topleft",legend=c("Sampling","Averaging",expression(sqrt(p(1-p)/N))),col=c("orange","blue","green"),lty=c(2,1,1),lw=3,cex=1.8)
axis(1,at=seq(1,M+1,1),labels=seq(0,M,1)) 
axis(2) 

