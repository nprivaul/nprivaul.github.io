// This code implements the computation of VaR and CTE for GMMBs by the
// spectral method of Feng and Volkmer, ASTIN Bull. 44, 2014.

// Uses the PNL scientific library https://github.com/pnlnum/pnl
//
// Compiles with c++ ap_GMMB_Spectral_VaR_CTE.c -lpnl 
 
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<time.h>
#include "pnl/pnl_specfun.h"
#include "pnl/pnl_integration.h"
#include "pnl/pnl_vector.h"

static double x0, nu, sigma, kappa, alpha, r, F0, maturity;

static int N;

static double binomial(double n, double k){
    if (k >= n) return 1;
    return pnl_fact(n) / (pnl_fact(k) * pnl_fact(n - k));
}

static double WhittakerM(double k, double m, double z){
    double x, y;
    if(z == 0){
        if (m > -0.5) return z;
        else return INFINITY;
    }
    x = -0.5 * z;
    y = 0.5 + m;
    return exp(x) * pow(z, y) * pnl_sf_hyperg_1F1(y - k, 1 + 2 * m, z);
}

static double WhittakerW(double k, double m, double z){
    double x, y, g;
    if (z == 0){
        g = fabs(m);
        if (g < 0.5) return z;
        else return INFINITY;
    }
    x = -0.5 * z;
    y = 0.5 + m;
    return exp(x) * pow(z, y) * pnl_sf_hyperg_U(y - k, 1 + 2 * m, z);
}

static double Pt (double s, double w)
{
  double mmu;
  double K = x0 * w;
  mmu = sqrt(nu * nu + 8 * s / pow(sigma,2)) / 2;
  return 4 / pow(sigma, 2) * tgamma(0.5+ mmu - kappa) / tgamma(1 + 2 * mmu) * pow(x0, kappa) * exp(0.25 / x0) * WhittakerM(kappa, mmu, 0.5 / x0) * pow(K, -kappa + 1) * exp(-0.25 / K) * WhittakerW(kappa - 1, mmu, 0.5/ K);
}

static double ft(int n, double t, double w){
  int k;
  double sm = 0;
  for (k = 0; k <= n; k++)
    sm += pow(-1, k) * binomial(n, k) * Pt((n + k) * log(2) / t, w);
  return sm * log(2) * pnl_fact(2 * n) / (pnl_fact(n) * pnl_fact(n - 1) * t);
}

static double weight(double k){
  return pow(-1, N - k) * pow(k, N) / pnl_fact(k) / pnl_fact(N - k);
}

static double P(double t, double w){
  double f1 = 0;
  int k = 1;
  for (; k <= N; k++){
	  f1 += weight(k) * ft(k, t, w);
  }
  return f1;
}

static double prob (double V){
  double B = (exp(-r * maturity) * alpha * F0 - V) / F0;
  return P(maturity, B);
}

static double Zt (double s, double w){
  double mmu;
  double K;
  K = x0 * w;
  mmu = sqrt(nu * nu + 0.8e1 * s * pow(sigma, -0.2e1)) / 0.2e1;
  return(0.4e1 / x0 * pow(sigma, -0.2e1) * tgamma(0.1e1 / 0.2e1 + mmu - kappa) / tgamma(0.1e1 + 0.2e1 * mmu) * pow(x0, kappa) * exp(0.1e1 / x0 / 0.4e1) * WhittakerM(kappa, mmu, 0.1e1 / x0 / 0.2e1) * (K * pow(K, -kappa + 0.1e1) * exp(-0.1e1 / K / 0.4e1) * WhittakerW(kappa - 0.1e1, mmu, 0.1e1 / K / 0.2e1) - pow(K, -kappa + 0.2e1) * exp(-0.1e1 / K / 0.4e1) * WhittakerW(kappa - 0.2e1, mmu, 0.1e1 / K / 0.2e1)));
}

static double ftZ(int n, double t, double w){
  int k;
  double sm = 0;
  for (k = 0; k <= n; k++){
	  sm += pow(-1, k) * binomial(n, k) * Zt((n + k) * log(2) / t, w);
  }
  return sm * log(2) * pnl_fact(2 * n) / (pnl_fact(n) * pnl_fact(n - 1) * t);
}

static double Z(double t, double w){
  double f1 = 0;
  int k;
  for (k = 1; k <= N; k++){
	  f1 += +weight(k) * ftZ(k, t, w);
  }
  return f1;
}

int AP_GMMB_Spectral_VaR_CTE(double F0, double alpha, double maturity, double r, double sigma, double risk_level, double me, double mu, double m, int N, double *ptvar, double *ptcte)
{

double Tpx = 0.757; 
double K1, K2, K3, s, theta, lambda;

double temp, target;

double t; 

	double left, right, B, xi;
    
	nu = 2 * (mu - m - r) / pow(sigma, 2);
	t = pow(sigma, 2)*maturity / 4;
	x0 = pow(sigma, 2) / 4 / me;
	kappa = (1 - nu) / 2;
	target=(1-risk_level)/Tpx;
	
	left = 0.0;
	right = 100.0;
	m = (left+right)/2;
	temp=prob(m);

	while(fabs(left - right) > 0.0000001){
		if(temp>target){
			left=m;
		}else{
			right=m;
		}
		m=(left+right)/2;
		temp=prob(m);
	}
    
	xi=1-Tpx*P(maturity,exp(-r*maturity)*alpha);
	B = (exp(-r*maturity)*F0*alpha - m) / F0;
    if (xi<risk_level)
    {
    *ptcte=exp(-r*maturity)*F0*alpha - Tpx*F0 / (1 - risk_level)*Z(maturity, B);
    }
    else
    {
    *ptcte=(exp(-r*maturity)*F0*alpha - Tpx*F0/(1-xi)*Z(maturity,B))*(1-xi)/0.2;
    }

    *ptvar=m;


  return  1;

}

int main(){

double risk_level = 0.80, me=0.0035, mu=0.09, m=0.01, ptvar, ptcte;
      
N=7;
      
maturity=10.0, F0=100.0, sigma=0.3, alpha=120/F0, r=0.04;

pnl_deactivate_mtherr();
  
printf("G=%.2f, alpha=%.2f, maturity=%.2f, r=%.2f, sigma=%.2f, risk_level=%.2f, me=%.2e, mu=%.2f, m=%.2f, N=%d.\n", alpha * F0, alpha, maturity, r, sigma, risk_level, me, mu, m, N);

AP_GMMB_Spectral_VaR_CTE(F0,alpha,maturity,r,sigma,risk_level,me,mu,m,N,&ptvar,&ptcte);

printf("Spectral GMMB VaR at p=%.0f%% with G/F0=%.0f%% is %%%.8f\n",risk_level*100,alpha*F0,ptvar);

printf("Spectral GMMB CTE at p=%.0f%% with G/F0=%.0f%% is %%%.8f\n",risk_level*100,alpha*F0,ptcte);

}
