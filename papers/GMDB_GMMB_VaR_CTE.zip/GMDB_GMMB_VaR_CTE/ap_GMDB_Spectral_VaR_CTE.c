// This code implements the computation of VaR and CTE for GMDBs by the
// spectral method of Feng and Volkmer, ASTIN Bull. 44, 2014.

// Uses the PNL scientific library https://github.com/pnlnum/pnl
//
// Compiles with c++ ap_GMDB_Spectral_VaR_CTE.c -lpnl 

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<time.h>
#include "pnl/pnl_specfun.h"
#include "pnl/pnl_integration.h"
#include "pnl/pnl_vector.h"

static double F0, x0, nu, sigma, kappa, r, maturity, alpha, rollup_rate, risk_level, alpha2;

static int n_, N, Tn;

static PnlVect *PQ;

static double binomial(double n, double k){
    if (k >= n) return 1;
    return pnl_fact(n) / (pnl_fact(k) * pnl_fact(n - k));
}

static double weight(double k){
  return pow(-1, N - k) * pow(k, N) / pnl_fact(k) / pnl_fact(N - k);
}

static double WhittakerM(double k, double m, double z){
    double x, y;
    if(z == 0){
        if (m > -0.5) return z;
        else return INFINITY;
    }
    x = -0.5 * z;
    y = 0.5 + m;
    return exp(x) * pow(z, y) * pnl_sf_hyperg_1F1(y - k, 1 + 2 * m, z);
}

static double WhittakerW(double k, double m, double z){
    double x, y, g;
    if (z == 0){
        g = fabs(m);
        if (g < 0.5) return z;
        else return INFINITY;
    }
    x = -0.5 * z;
    y = 0.5 + m;
    return exp(x) * pow(z, y) * pnl_sf_hyperg_U(y - k, 1 + 2 * m, z);
}

static double Pt (double s, double w)
{
  double mmu;
  double K = x0 * w;
  mmu = sqrt(nu * nu + 8 * s / pow(sigma,2)) / 2;
  return 4 / pow(sigma, 2) * tgamma(0.5+ mmu - kappa) / tgamma(1 + 2 * mmu) * pow(x0, kappa) * exp(0.25 / x0) * WhittakerM(kappa, mmu, 0.5 / x0) * pow(K, -kappa + 1) * exp(-0.25 / K) * WhittakerW(kappa - 1, mmu, 0.5/ K);
}

static double ft(int n, double t, double w){
  int k;
  double sm = 0;
  for (k = 0; k <= n; k++)
    sm += pow(-1, k) * binomial(n, k) * Pt((n + k) * log(2) / t, w);
  return sm * log(2) * pnl_fact(2 * n) / (pnl_fact(n) * pnl_fact(n - 1) * t);
}

static double P(double t, double w){
  double f1 = 0;
  int k = 1;
  for (; k <= N; k++){
	  f1 += weight(k) * ft(k, t, w);
  }
  return f1;
}

static double prob (double V){
  double B = (exp(-r * maturity) * alpha * F0 - V) / F0;
  return P(maturity, B);
}

static double Zt (double s, double w){
  double mmu;
  double K;
  K = x0 * w;
  mmu = sqrt(nu * nu + 0.8e1 * s * pow(sigma, -0.2e1)) / 0.2e1;
  return(0.4e1 / x0 * pow(sigma, -0.2e1) * tgamma(0.1e1 / 0.2e1 + mmu - kappa) / tgamma(0.1e1 + 0.2e1 * mmu) * pow(x0, kappa) * exp(0.1e1 / x0 / 0.4e1) * WhittakerM(kappa, mmu, 0.1e1 / x0 / 0.2e1) * (K * pow(K, -kappa + 0.1e1) * exp(-0.1e1 / K / 0.4e1) * WhittakerW(kappa - 0.1e1, mmu, 0.1e1 / K / 0.2e1) - pow(K, -kappa + 0.2e1) * exp(-0.1e1 / K / 0.4e1) * WhittakerW(kappa - 0.2e1, mmu, 0.1e1 / K / 0.2e1)));
}

static double ftZ(int n, double t, double w){
  int k;
  double sm = 0;
  for (k = 0; k <= n; k++){
	  sm += pow(-1, k) * binomial(n, k) * Zt((n + k) * log(2) / t, w);
  }
  return sm * log(2) * pnl_fact(2 * n) / (pnl_fact(n) * pnl_fact(n - 1) * t);
}

static double Z(double t, double w){
  double f1 = 0;
  int k;
  for (k = 1; k <= N; k++){
	  f1 += +weight(k) * ftZ(k, t, w);
  }
  return f1;
}

static double SumP(double V)
{
    double sum = 0.;
    int i;
    for (i= 1; i < Tn+1; i++)
    {
      sum = sum + pnl_vect_get(PQ,i-1)*P(i/n_, (exp((rollup_rate-r) * i/ n_) * F0*alpha - V) / F0);
    }
    return sum;
}

double Y(double V)
{
    return SumP(V) - (1 - alpha2) ;
}

static double derivative_Y(double V) {
    double dt = 0.0001;
    double right;
    double t1, t2;
    t1 = Y(V);
    right = V - dt;
    t2 = Y(right);
    double dev = (t1 - t2) / dt;
    V = right;
    return dev;
}

static double Multiplier(double V,double T)
{
return exp((rollup_rate-r)*T)*F0*alpha*P(T, (exp((rollup_rate-r) * T) * F0*alpha - V) / F0) - F0*Z(T, (exp((rollup_rate-r) * T) * F0*alpha - V) / F0);
}

static double CTE(double V)
{
  double sum = 0, i;
    for ( i= 1; i < Tn+1;i++)
    {
        sum = sum + pnl_vect_get(PQ,i-1)*Multiplier(V, i/n_);
    }
    return sum/(1-alpha2);
}

static double CTE2(double V)
{
    return CTE(V)*(1-alpha2)/(1-risk_level);
}

int AP_GMDB_Spectral_VaR_CTE(double F0, double alpha, double maturity, double r, double sigma, double risk_level, double rollup_rate, double me, double mu, double m, int n_, int N, double *ptvar, double *ptcte)
{

double t;

PnlVect *Tpx, *Qx;

alpha2 = risk_level;

double left, B, xi;

	Tn = (int) maturity/n_;

    Tpx = pnl_vect_create_from_list(Tn+1, 1.0,0.98246,0.96348,0.94304,0.92113,0.89775,0.87275,0.84606,0.81778,0.78807,0.75700);
    Qx = pnl_vect_create_from_list(Tn+1, 0.01753,0.01932,0.02122,0.02323,0.02538,0.02785,0.03059,0.03343,0.03633,0.03942, 0.04299);

    PQ = pnl_vect_create(Tn+1);
    for (int j=0; j< Tn+1; j++)
    {
        pnl_vect_set(PQ, j, pnl_vect_get(Tpx, j)*pnl_vect_get(Qx, j)/n_);
    }
    
	nu = 2 * (mu - m - r) / pow(sigma, 2);
	t = pow(sigma, 2)*maturity / 4;
	x0 = pow(sigma, 2) / 4 / me;
	kappa = (1 - nu) / 2;
	
    xi= 1. - SumP(0);
    if (risk_level < xi )
    {
        alpha2 = xi;
    }
   
    double right = 30;
    do
    {
        left = right;
        right = left - Y(left) / derivative_Y(left);
    } while (fabs(right - left) >= 0.00001);
    
    	
    B = (exp(-r*maturity)*F0*alpha - m) / F0;

   
if (xi<risk_level)
    {
    *ptcte=CTE(left);
    }
    else
    {
      *ptcte=CTE2(left);
    }

    *ptvar=left;

    pnl_vect_free (&Tpx);
    pnl_vect_free (&Qx);
    pnl_vect_free (&PQ);
    
  return  1;

}

int main(){

double me=0.0035, mu=0.09, m=0.01, ptvar, ptcte;
      
n_=1, N=7;
      
F0=100.0, sigma=0.3, rollup_rate=0.06, risk_level = 0.80, r=0.07, maturity=10.0, alpha=75/F0;

pnl_deactivate_mtherr();
  
printf("G=%.2f, alpha=%.2f, maturity=%.2f, r=%.2f, sigma=%.2f, risk_level=%.2f, rollup_rate=%.2f, me=%.2e, mu=%.2f, m=%.2f, n_=%d, N=%d.\n", alpha * F0, alpha, maturity, r, sigma, risk_level, rollup_rate, me, mu, m, n_, N);

AP_GMDB_Spectral_VaR_CTE(F0,alpha,maturity,r,sigma,risk_level,rollup_rate,me,mu,m,n_,N,&ptvar,&ptcte);

printf("Spectral GMDB VaR at p=%.0f%% with G/F0=%.0f%% is %%%.8f\n",risk_level*100,alpha*F0,ptvar);

printf("Spectral GMDB CTE at p=%.0f%% with G/F0=%.0f%% is %%%.8f\n",risk_level*100,alpha*F0,ptcte);

}
