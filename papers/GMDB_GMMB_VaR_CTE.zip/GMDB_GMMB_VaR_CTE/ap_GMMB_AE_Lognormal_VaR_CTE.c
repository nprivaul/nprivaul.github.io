// This code implements the computation of VaR and CTE for GMMBs with
// additional earnings by the lognormal approximation of Privault and Wei,
// ASTIN Bull. 2018.
// It uses the PNL scientific library https://github.com/pnlnum/pnl

// Uses the PNL scientific library https://github.com/pnlnum/pnl
//
// Compiles with c++ ap_GMMB_AE_Lognormal_VaR_CTE.c -lpnl

#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "pnl/pnl_integration.h"
#include "pnl/pnl_root.h"
#include "pnl/pnl_cdf.h"

static double sigma, maturity, F0, alpha, r, me, mu, m, risk_level, rho, C, tPx, alpha2;

static long double const pi = 3.14159265358979323846264338L; 

static double Normal(double d)
{

  int which,i,A; 
  double p; 
  double q; 
  double mean; 
  double sd; 
  int status; 
  double bound; 

  which=1; 
  mean=0.0; 
  sd=1.0; 

  pnl_cdf_nor(&which,&p,&q,&d,&mean,&sd,&status,&bound);

  return p;
}

static double p(double z)
{
	return exp(-pow((pow(sigma, 2)*maturity / 2 + log(z)), 2) / (2 * pow(sigma, 2)*maturity)) / sqrt(2 * pi*pow(sigma, 2)*maturity);
}

static double q(double z)
{
	return exp(-pow((pow(sigma, 2)*maturity + log(z)), 2) / (2 * pow(sigma, 2)*maturity)) / sqrt(2 * pi*pow(sigma, 2)*maturity);
}

static double quantile1(double z)
{
	return log(z) / sqrt(pow(sigma, 2)*maturity) + 0.5*sqrt(pow(sigma, 2)*maturity);
}

static double quantile2(double z)
{
	return log(z) / sqrt(pow(sigma, 2)*maturity) - 0.5*sqrt(pow(sigma, 2)*maturity);
}

static double quantile3(double z)
{
	return log(z) / sqrt(pow(sigma, 2)*maturity) + sqrt(pow(sigma, 2)*maturity);
}

static double quantile4(double z)
{
	return log(z) / sqrt(pow(sigma, 2)*maturity) - sqrt(pow(sigma, 2)*maturity);
}

static double aT(double z)
{
	return (Normal(quantile1(z)) - Normal(quantile2(z))) / (p(z)*pow(sigma, 2));
}

static double bT(double z)
{
	return (Normal(quantile3(z)) - Normal(quantile4(z))) / (q(z)*pow(sigma, 2));
}

static double square_sigma(double z)
{
	return log(2 * (bT(z) / aT(z) - 1 - z) / (aT(z)*pow(sigma, 2))) / maturity;
}

static double mean_mu(double z)
{
	return 1 - 2 * log(aT(z)) / (maturity*square_sigma(z));
}

static double B(double V)
{
  double res = (exp(-r*maturity)*alpha*F0 - V) / F0;
	return res;
}

static double inte_f(double V, double z)
{
	double percentile = (log((B(V) - z) / me) + mean_mu(z)*square_sigma(z)*maturity / 2) / (sqrt(square_sigma(z)*maturity));
	
	return Normal(percentile);
}

static double inte_f2(double w, double z)
{
	double percentile = (log((w - z) / me) + mean_mu(z)*square_sigma(z)*maturity / 2) / (sqrt(square_sigma(z)*maturity));
	
	return Normal(percentile);
}

static double DPhi(double z)
{
        double temp = log(z) - (mu - m - r)*maturity;
	double s = -pow(temp, 2) / (2 * pow(sigma, 2) * maturity);
        return exp(s) / (sqrt(2 * pi*maturity)*sigma*z);
}

static double Q(double V, double z)
{
	return inte_f(V, z)*DPhi(z);
}

static double Q2(double w, double z)
{
	return inte_f2(w, z)*DPhi(z);
}

static double integral_Q2(double w) 
{
	double sum = 0, z;
	double end = w;
	double res;
	for (z = 0; z<= end; z = z + 0.005)
	{
		res = Q2(w, z);
		if (isnan(res)) continue;
		sum = sum + res*0.005;
	}
	return sum;
}

static double inte_f_(double V, double z)
{
        double c1=(mean_mu(z)-1)*square_sigma(z)*maturity;
        double multi=exp(-c1/2);
        double percentile1 = (log((B(V) - z) / me) + (mean_mu(z)-2)*square_sigma(z)*maturity / 2) / (sqrt(square_sigma(z)*maturity));
        return multi*Normal(percentile1);
}

static double Q_(double V,double z)
{       
        return (z*inte_f(V,z)+me*inte_f_(V,z))*DPhi(z);
}

static double  xi(double w)
{
   return 1-tPx*integral_Q2(w);
}

static double c1(double z)
{
    return mean_mu(z)*square_sigma(z)*maturity / 2;
}

static double c2(double z)
{
    return sqrt(square_sigma(z)*maturity);
}

static double Int_f1(double V,double z)
{
    double percentile1=(log(((exp(-r*maturity)*F0*alpha-V)/F0 - z) / me) + c1(z)) / c2(z);
    if (square_sigma(z)>0)
    {
        return Normal(percentile1);
    }
    else return 0;
}

static double DP(double V, double z)
{
    double temp = log(z) - (mu - m - r)*maturity;
    double s = -pow(temp, 2) / (2 * pow(sigma, 2) * maturity);
    return exp(s) / (sqrt(2 * pi*maturity)*sigma*z);
}

static double function1(double u, void *p)
{
    double *tmp;
    tmp = (double *)p;
    return Int_f1(*tmp, u)*DP(*tmp, u);
}

static double Int_Q1(double V)
{
    double h, result,abserr;
    int neval;
    PnlFunc func;
    func.F = function1;
    func.params = &V;
    h=(exp(-r*maturity)*F0*alpha-V)/F0;
    if (h<=0)
    {
        return 0;
    }
    else
    {
        pnl_integration_qag(&func,0.0,h,0.00001,0.0001,0,&result,&abserr,&neval);
        return result;
    }
}

static double Int_f2(double V,double z)
{
    double percentile2=(log((rho*z-(exp(-r*maturity)*rho*F0*alpha+V)/F0) / me) + c1(z)) / c2(z);
    return Normal(percentile2);
}

static double function2(double u, void *p)
{
    double *tmp;
    tmp = (double *)p;
    return Int_f2(*tmp, u)*DP(*tmp, u);
}

static double Int_Q2(double V)
{
    double l, h, result,abserr;
    int neval;
    PnlFunc func;
    func.F = function2;
    func.params = &V;
    l= exp(-r*maturity)*F0*alpha/F0+V/(rho*F0);
    h= exp(-r*maturity)*(rho*F0*alpha+C)/(rho*F0);
    pnl_integration_qag(&func,l,h,0.0000001,0.0001,0,&result,&abserr,&neval);
    return result;
}

static double Int_f3(double V,double z)
{
    double percentile3=(log((exp(-r*maturity)*C-V)/F0/me) + c1(z)) / c2(z);
    return Normal(percentile3);
}

static double function3(double u, void *p)
{
    double *tmp;
    tmp = (double *)p;
    if (u>=1200) {
        return 0;
    }
    else
    {
        return Int_f3(*tmp, u)*DP(*tmp, u);
    }
}

static double Int_Q3(double V)
{
    double l, result,abserr;
    int neval;
    PnlFunc func;
    func.F = function3;
    func.params = &V;
    l= exp(-r*maturity)*(rho*F0*alpha+C)/(rho*F0);
    pnl_integration_qag(&func,l, PNL_POSINF, 0.001,0.01,0,&result,&abserr,&neval);
    return result;
}

static double Int_Q(double V)
{
  if (rho>0) {return Int_Q1(V)+Int_Q2(V)+Int_Q3(V);}
  else {return Int_Q1(V);}
}

static double integral_Q(double x, void *p)
{
    return Int_Q(x) - (1 - alpha2) / tPx;
}

static void bisection(double *var)
{
    double x1, x2, r, tol;
    PnlFunc func;
    
    x1 = -1.0;
    x2 = 100.;
    tol= 0.00001;
    func.F = integral_Q;
    func.params = NULL;
    r=pnl_root_brent(&func, x1, x2, &tol);
    *var =r;
}

static double g1(double V, double z)
{
    double percentile1;
    double multi=exp(-(mean_mu(z)-1)*square_sigma(z)*maturity/2.);
    if (square_sigma(z)>0)
    {
        percentile1 = (log((B(V) - z) / me) + (mean_mu(z)-2)*square_sigma(z)*maturity / 2) / (sqrt(square_sigma(z)*maturity));
        return multi*Normal(percentile1);
    }
    else return 0;
}

static double z1(double u, void *p)
{
    double *tmp;
    tmp = (double *)p;
    return ((exp(-r*maturity)*F0*alpha-F0*u)*Int_f1(*tmp, u)- F0*me*g1(*tmp, u))*DP(*tmp, u);
}

static double Int_Z1(double V)
{
    double h, result,abserr;
    int neval;
    PnlFunc func;
    func.F = z1;
    func.params = &V;
    h= (exp(-r*maturity)*F0*alpha-V)/F0;
    if (h<=0)
    {
        return 0;
    }
    else
    {
        pnl_integration_qag(&func,0.0,h,0.00001,0.0001,0,&result,&abserr,&neval);
        return result;
    }
    return result;
}

static double g2(double V, double z)
{
    double multi=exp(-(mean_mu(z)-1)*square_sigma(z)*maturity/2);
    double percentile1 = (log((rho*z-(exp(-r*maturity)*rho*F0*alpha+V)/F0) / me) + (mean_mu(z)-2)*square_sigma(z)*maturity / 2) / c2(z);
    return multi*Normal(percentile1);
}

static double z2(double u, void *p)
{
    double *tmp;
    tmp = (double *)p;
    return (rho*(F0*u-exp(-r*maturity)*F0*alpha)*Int_f2(*tmp, u)- F0*me*g2(*tmp, u))*DP(*tmp, u);
}

static double Int_Z2(double V)
{
    double l, h, result,abserr;
    int neval;
    PnlFunc func;
    func.F = z2;
    func.params = &V;
    l = exp(-r*maturity)*alpha+V/(rho*F0);
    h = exp(-r*maturity)*(rho*F0*alpha+C)/(rho*F0);
    pnl_integration_qag(&func,l, h, 0.001,0.01,0,&result,&abserr,&neval);
    return result;
}
double g3(double V, double z)
{
    double multi=exp(-(mean_mu(z)-1)*square_sigma(z)*maturity/2);
    double percentile1 = (log((exp(-r*maturity)*C-V)/F0/me) + (mean_mu(z)-2)*square_sigma(z)*maturity / 2) / c2(z);
    return multi*Normal(percentile1);
}

static double z3(double u, void *p)
{
    double *tmp;
    tmp = (double *)p;
    if (u>=1200) {
        return 0;
    }
    else
    {
        return ((exp(-r*maturity)*C)*Int_f3(*tmp, u)- F0*me*g3(*tmp, u))*DP(*tmp, u);
    }
}

static double Int_Z3(double V)
{
    double l, result,abserr;
    int neval;
    PnlFunc func;
    func.F = z3;
    func.params = &V;
    l=exp(-r*maturity)*(rho*F0*alpha+C)/(rho*F0);
    pnl_integration_qag(&func,l, PNL_POSINF, 0.001,0.01,0,&result,&abserr,&neval);
    return result;
}

static double CTE(double V)
{
  if (rho>0) {return tPx*(Int_Z1(V)+ Int_Z2(V)+Int_Z3(V))/ (1 - alpha2);}
  else {return tPx*Int_Z1(V)/ (1 - alpha2);}
}

static double CTE2(double V)
{
        return CTE(V)*(1-alpha2)/(1-risk_level);
}

int AP_GMMB_AE_Lognormal_VaR_CTE(double F0, double alpha, double maturity, double r, double sigma, double risk_level, double me, double mu, double m, double rho, double C, double *ptvar, double *ptcte)
{

 tPx = 0.757;

 alpha2 = xi(exp(-r*maturity)*alpha);

 if (risk_level > alpha2) alpha2=risk_level;

	double VaR;

        bisection(&VaR);

        *ptvar=VaR;

        if(risk_level == alpha2) *ptcte=CTE(VaR);
	
        if(risk_level < alpha2)	*ptcte=CTE2(VaR);

	return 0;

}

int main(){

double ptvar, ptcte;
      
// Set rho=0 in the absence of AE.

F0=100.0, alpha=100./F0, risk_level = 0.90, rho=0., maturity=10.0, r=0.04, sigma=0.3, me=0.0035, mu=0.09, m=0.01, C=1.0*F0;

printf("G=%.2f,maturity=%.2f, r=%.2f, sigma=%.2f, risk_level=%.2f, me=%.2e, mu=%.2f, m=%.2f, rho=%.2f, C=%.2f.\n", alpha * F0, maturity, r, sigma, risk_level, me, mu, m, rho, C);

AP_GMMB_AE_Lognormal_VaR_CTE(F0,alpha,maturity,r,sigma,risk_level,me,mu,m,rho,C,&ptvar,&ptcte);

printf("Lognormal approximation GMMB AE VaR at p=%.0f%% with G/F0=%.0f%% is %%%.8f\n",risk_level*100,alpha*F0,ptvar);

printf("Lognormal approximation GMMB AE CTE at p=%.0f%% with G/F0=%.0f%% is %%%.8f\n",risk_level*100,alpha*F0,ptcte);

}

 
