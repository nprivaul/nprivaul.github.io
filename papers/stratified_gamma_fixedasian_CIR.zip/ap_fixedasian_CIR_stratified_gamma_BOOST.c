// This code requires the BOOST library www.boost.org/
 
#include <cmath>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "float.h"
#include <math.h>
#include <cmath>

#include <boost/math/special_functions/bessel.hpp>

// using namespace std;

const double pi = 3.141592653;

typedef struct { double mean, var, pdfcon, logpdfcon; } ret;

using namespace boost::math;

double BI11(double v, double z) {
  if (z <= 200 && v <= 30) {
    return cyl_bessel_i(v + 1, z) / cyl_bessel_i(v - 1, z);
  } else {
    return 1.0;
  }
}

double BI31(double v, double z) {
  if (z <= 200 && v <= 30) {
    return cyl_bessel_i(v - 3, z) / cyl_bessel_i(v - 1, z);
  } else {
    return 1.0;
  }
}

double BI21(double v, double z) {
  if (z <= 200 && v <= 30) {
    return cyl_bessel_i(v - 2, z) / cyl_bessel_i(v - 1, z);
  } else {
    return 1.0;
  }
}

double BI01(double v, double z) {
  if (z <= 200 && v <= 30) {
    return cyl_bessel_i(v, z) / cyl_bessel_i(v - 1, z);
  } else {
    return 1.0;
  }
}

double BI(double v, double z) {
  if (z <= 700 && v <= 30) {
    return cyl_bessel_i(v, z);
  } else {
    return exp(z) / sqrt(2 * pi * z);
  }
}

double logBI(double v, double z) {
  if (z <= 500 && v <= 30) {
    return log(BI(v, z));
  } else {
    return z - 0.5 * log(2 * pi * z);
  }
}

ret meanvar(double a, double b, double s0, double st, double sigma, double T) {
  double logh, logpdfcon, pdfcon, g, h, i, j, g1, h1, H1, i1, I1, j1, J1, g2,
      h2, H2, i2, I2, j2, J2, moment1, moment2, mean, var;
  double dens, bc, delta, ggm, gm, alf, sg2 = pow(sigma, 2);

  bc = 4 * b * sqrt(s0 * st * exp(-b * T)) / (sg2 * (1 - exp(-b * T)));
  // first moment
  delta = (s0 + st) * (exp(2 * b * T) - 2 * b * T * exp(b * T) - 1);
  alf = 2 * a / sg2;
  gm = BI01(2 * a / sg2, bc) + BI21(2 * a / sg2, bc);
  ggm = BI31(2 * a / sg2, bc) + BI11(2 * a / sg2, bc);
  moment1 = -sg2 / b / b + (sg2 * T * (exp(2 * b * T) - 1) / 2 + delta + (b * T + exp(b * T) * (b * T - 2) + 2) * exp(b * T / 2) * sqrt(s0 * st) * gm) / (exp(b * T) - 1) / (exp(b * T) - 1) / b;
  mean = moment1;
  // second derivative
  g = 2 * b / (sg2 * (1 - exp(-b * T)));
  h = exp(-2 * b * st / sg2 - g * (s0 + st) * exp(-b * T));
  logh = -2 * b * st / sg2 - g * (s0 + st) * exp(-b * T);
  i = pow(st * exp(b * T) / s0, a / sg2 - 0.5);
  j = exp(logBI(2 * a / sg2 - 1, bc));
  pdfcon = 1 / (g * h * i * j);
  logpdfcon = -log(g) - logh - log(i) - logBI(2 * a / sg2 - 1, bc);
  g1 = 2 * T * exp(-b * T) / pow(1 - exp(-b * T), 2) - 2 / (b * (1 - exp(-b * T)));
  h1 = h * ((a * T + s0 + st) / b - 2 * (s0 + st) * T * exp(-b * T) / (1 - exp(-b * T)) - 2 * (s0 + st) * T * exp(-2 * b * T) / pow(1 - exp(-b * T), 2) + 2 * (s0 + st) * exp(-b * T) / (b * (1 - exp(-b * T))));
  H1 = (a * T + s0 + st) / b - 2 * (s0 + st) * T * exp(-b * T) / (1 - exp(-b * T)) - 2 * (s0 + st) * T * exp(-2 * b * T) / pow(1 - exp(-b * T), 2) + 2 * (s0 + st) * exp(-b * T) / (b * (1 - exp(-b * T)));
  i1 = T * (sg2 / 2 - a) * pow(st * exp(b * T) / s0, a / sg2 - 0.5) / b;
  I1 = T * (sg2 / 2 - a) / b;
  j1 = (sqrt(s0 * st) * (T * b + exp(T * b) * (T * b - 2) + 2) * (exp(logBI(2 * a / pow(sigma, 2), bc)) + exp(logBI(2 * a / pow(sigma, 2) - 2, bc)))) / (b * (pow(exp(T * b) - 1, 2) * sqrt(exp(-T * b))));
  J1 = (sqrt(s0 * st) * (T * b + exp(T * b) * (T * b - 2) + 2) * exp(logBI(2 * a / pow(sigma, 2), bc) - logBI(2 * a / sg2 - 1, bc))) / (b * (pow(exp(T * b) - 1, 2) * sqrt(exp(-T * b)))) + (sqrt(s0 * st) * (T * b + exp(T * b) * (T * b - 2) + 2) * exp(logBI(2 * a / pow(sigma, 2) - 2, bc) - logBI(2 * a / sg2 - 1, bc))) / (b * (pow(exp(T * b) - 1, 2) * sqrt(exp(-T * b))));
  g2 = -(2 * sg2 * exp(T * b) * (1 + exp(2 * T * b) - pow(b * T, 2) - T * b + exp(T * b) * (T * b - pow(T * b, 2) - 2))) /
       (pow(b * (exp(T * b) - 1), 3));
  h2 = sg2 * ((s0 + st) * (exp(2 * T * b) * (-2 * b * b * T * T + 2 * T * b - 1) - exp(T * b) * (2 * b * b * T * T + 2 * T * b + 1) + exp(3 * T * b) + 1) + a * T * pow(exp(T * b) - 1, 3)) * h / pow(b * (exp(T * b) - 1), 3) + exp(2 * log(h1) - log(h));
  H2 = sg2 * ((s0 + st) * (exp(2 * T * b) * (-2 * b * b * T * T + 2 * T * b - 1) - exp(T * b) * (2 * b * b * T * T + 2 * T * b + 1) + exp(3 * T * b) + 1) + a * T * pow(exp(T * b) - 1, 3)) / pow(b * (exp(T * b) - 1), 3) + H1 * H1;
  i2 = T * pow(sigma, 4) * (a / sg2 - 0.5) * ((a * T - 0.5 * T * sg2) / (b * b * sg2) - 1 / pow(b, 3)) * pow(st * exp(T * b) / s0, a / sg2 - 0.5);
  I2 = T * pow(sigma, 4) * (a / sg2 - 0.5) * ((a * T - 0.5 * T * sg2) / (b * b * sg2) - 1 / pow(b, 3));
  j2 = ((BI(2 * a / pow(sigma, 2) - 3, bc) + 2 * BI(2 * a / pow(sigma, 2) - 1, bc) + BI(2 * a / pow(sigma, 2) + 1, bc)) * (2 * exp(T * b) * pow(T * b + exp(T * b) * (T * b - 2) + 2, 2)) / pow(b, 2) - sg2 * (exp(T * b) - 1) / (pow(b, 3) * sqrt(s0 * st * exp(-b * T))) * (BI(2 * a / pow(sigma, 2), bc) + BI(2 * a / pow(sigma, 2) - 2, bc)) * (exp(2 * T * b) * (4 - b * b * T * T + 2 * T * b) - 2 * exp(T * b) * (3 * b * b * T * T + 4) - b * b * T * T - 2 * T * b + 4)) * (s0 * st) / (2 * pow(exp(T * b) - 1, 4));
  J2 = ((exp(logBI(2 * a / pow(sigma, 2) - 3, bc) - logBI(2 * a / pow(sigma, 2) - 1, bc)) + 2 + exp(logBI(2 * a / pow(sigma, 2) + 1, bc) - logBI(2 * a / pow(sigma, 2) - 1, bc))) * (2 * exp(T * b) * pow(T * b + exp(T * b) * (T * b - 2) + 2, 2)) / pow(b, 2) - sg2 * (exp(T * b) - 1) / (pow(b, 3) * sqrt(s0 * st * exp(-b * T))) * (exp(logBI(2 * a / pow(sigma, 2), bc) - logBI(2 * a / pow(sigma, 2) - 1, bc)) + exp(logBI(2 * a / pow(sigma, 2) - 2, bc) - logBI(2 * a / pow(sigma, 2) - 1, bc))) * (exp(2 * T * b) * (4 - b * b * T * T + 2 * T * b) - 2 * exp(T * b) * (3 * b * b * T * T + 4) - b * b * T * T - 2 * T * b + 4)) * (s0 * st) / (2 * pow(exp(T * b) - 1, 4));
  moment2 = 2 * (I1 + H1) * (J1 + g1 / g) + 2 * (g1 / g * J1 + H1 * I1) +
            (J2 + H2 + I2 + g2 / g);
  var = -2.0 * sg2 * sg2 / pow(b, 4) - sg2 * (1 - exp(b * T) * (1 + 2.0 * b * T)) * (sg2 / b / b + moment1) / b / b / (exp(b * T) - 1) + (-sg2 * sg2 * T * T * exp(2.0 * b * T) / b - 2.0 * sg2 * T * (s0 + st) * (exp(2.0 * b * T) - exp(b * T) * (1 + b * T)) / b - sg2 * T * sqrt(s0 * st * exp(b * T)) * (b * T + exp(b * T) * (3 * b * T - 4) + 4) * gm / 2.0 / b + exp(b * T) * s0 * st * pow(b * T + exp(b * T) * (b * T - 2.0) + 2.0, 2) * (2 + ggm - gm * gm) / b) / b / pow(exp(b * T) - 1, 2);
  if (var < moment2 - pow(moment1, 2)) {
    var = moment2 - pow(moment1, 2);
  }
  sg2 = sigma * sigma;
  bc = 4 * b * sqrt(s0 * st * exp(-b * T)) / (sg2 * (1 - exp(-b * T)));
  dens = 2 * b * exp(logBI(2 * a / pow(sigma, 2) - 1, bc) - 2 * b * (st + s0 * exp(-b * T)) / sg2 / (1 - exp(-b * T))) * exp((a / sg2 - 0.5) * log(st * exp(b * T) / s0)) / sg2 / (1 - exp(-b * T));
  ret t;
  t.mean = mean;
  t.var = var, t.pdfcon = dens, t.logpdfcon = log(dens);
  return t;
}

static int Stratified_Gamma_FixedAsianCIR(int call_or_put,double pseudo_stock, double pseudo_strike, double t, double a, double b, double sigma, double *ptprice)
{

double CTtK, PTtK;

/*  Call Price */
CTtK=0;
 
  int n;
  double g, h, i, j, pdfcon, bc, dfcon, st, barb;
  double precision;
  double ymax, s, ynow, result, K;

  precision=100; 
  K=pseudo_strike*t;
  
  double sg2, x, z;
  double Price = 0;
  double dens, mean, var, logpdfcon = 0, k, theta, sdlog, meanlog;
  double end, start = 0.00001;
  sg2 = sigma * sigma;
  x = start;
  dens = 0.0;
  while (dens < 0.00000001) {
    bc = 4 * b * sqrt(pseudo_stock * x * exp(-b * t)) / (sg2 * (1 - exp(-b * t)));
    dens = 2 * b * exp(logBI(2 * a / pow(sigma, 2) - 1, bc) - 2 * b * (x + pseudo_stock * exp(-b * t)) / sg2 / (1 - exp(-b * t))) * exp((a / sg2 - 0.5) * log(x * exp(b * t) / pseudo_stock)) / sg2 / (1 - exp(-b * t));
    x += 0.01;
  }
  while (dens >= 0.00000001) {
    bc = 4 * b * sqrt(pseudo_stock * x * exp(-b * t)) / (sg2 * (1 - exp(-b * t)));
    dens = 2 * b * exp(logBI(2 * a / pow(sigma, 2) - 1, bc) - 2 * b * (x + pseudo_stock * exp(-b * t)) / sg2 / (1 - exp(-b * t))) * exp((a / sg2 - 0.5) * log(x * exp(b * t) / pseudo_stock)) / sg2 / (1 - exp(-b * t));
    x += 0.01;
  }
  end = x;
  double deltaz, deltax = (end) / precision;
  for (x = start; x <= end; x += deltax) {
    ret calculate = meanvar(a, b, pseudo_stock, x, sigma, t);
    mean = calculate.mean;
    var = calculate.var;
    pdfcon = calculate.pdfcon;
    logpdfcon = calculate.logpdfcon;
    k = mean * mean / var;
    theta = var / mean;
    sdlog = sqrt(log(var / pow(mean, 2) + 1));
    meanlog = log(mean) - pow(sdlog, 2) / 2;
    deltaz = 5 * sqrt(var) / precision;
    bc = 4 * b * sqrt(pseudo_stock * x * exp(-b * t)) / (sg2 * (1 - exp(-b * t)));
    dens = 2 * b * exp(logBI(2 * a / pow(sigma, 2) - 1, bc) - 2 * b * (x + pseudo_stock * exp(-b * t)) / sg2 / (1 - exp(-b * t))) * exp((a / sg2 - 0.5) * log(x * exp(b * t) / pseudo_stock)) / sg2 / (1 - exp(-b * t));
    if (k > 0) {
    Price += deltax * dens * (k * theta * gamma_q(k + 1, K * (1 + 1 / theta)) - K * (1 + theta) * gamma_q(k, K * (1 + 1 / theta))) / pow(1 + theta, k + 1);
    }
  }
  CTtK=Price / t;

/*  Put Price from Parity*/
  barb=sqrt(b*b+2*sg2);

  PTtK = CTtK + exp(-pseudo_stock * (-2) *(exp(-barb*t)-1)/(b+barb+exp(-barb*t)*(barb-b)) - a*((barb-b)*t/sg2+2*log((b+barb+exp(-barb*t)*(barb-b))/2/barb)/sg2)) * ( pseudo_strike - (1/t) * ( - pseudo_stock*((2*barb*(exp(-barb*t)-1)-2*t*sg2*exp(-barb*t))/(barb*(barb+b+exp(-barb*t)*(barb-b)))-(2*sg2*(exp(-barb*t)-1)*(1-exp(-barb*t)*(barb-b)*t+exp(-barb*t)))/(barb*(barb+b+exp(-barb*t)*(barb-b)))/(barb*(barb+b+exp(-barb*t)*(barb-b))))+(a/barb)*(t+2*(1-exp(-barb*t)*(barb-b)*t+exp(-barb*t))/(barb+b+exp(-barb*t)*(barb-b))-2/barb)));

/*Price*/
  if(call_or_put)
    *ptprice = CTtK;
  else
    *ptprice = PTtK;

   return  0;

}

int main()
{
  int call_or_put;
  double stock,strike,t,a,b,sigma,ptprice;

  stock = 0.1;
  strike = 0.08;
  t = 0.5;
  a = 0.15;
  b = 1.5;
  sigma=0.2;

  call_or_put=1;
  Stratified_Gamma_FixedAsianCIR(call_or_put,stock,strike,t,a,b,sigma,&ptprice);

  printf("Asian call price=%f\n",ptprice);

  call_or_put=0;
  Stratified_Gamma_FixedAsianCIR(call_or_put,stock,strike,t,a,b,sigma,&ptprice);

  printf("Asian put price=%f\n",ptprice);

}

