
#include "math.h"
#include "float.h"
#include "stdio.h"

double pi = 3.14159265358979323846264338;

bool IsFiniteNumber(double x) 
    {
        return (x <= DBL_MAX && x >= -DBL_MAX); 
    }

double phi(double x)
{
  return 0.5+0.5*erf(x/sqrt(2.0)); 
}

double p(double sigma,double t, double z)
{
  return exp(-pow(sigma*sigma*t/2+log(z),2)/2/sigma/sigma/t)/sqrt(2*pi*sigma*sigma*t);
}

double q(double sigma,double t, double z)
{
  return exp(-pow(sigma*sigma*t+log(z),2)/2/sigma/sigma/t)/sqrt(2*pi*sigma*sigma*t);
}

double a(double sigma,double t, double z)
{
      return (phi(log(z)/sigma/sqrt(t)+sigma*sqrt(t)/2.0)-phi(log(z)/sigma/sqrt(t)-sigma*sqrt(t)/2.0))/p(sigma,t,z)/sigma/sigma; 

}

double b(double sigma,double t, double z)
{

    return (phi(log(z)/sigma/sqrt(t)+sigma*sqrt(t))-phi(log(z)/sigma/sqrt(t)-sigma*sqrt(t)))/q(sigma,t,z)/sigma/sigma;

}

static int Stratified_LogNormal_FixedAsian(int call_or_put,double pseudo_stock, double pseudo_strike, double t, double r, double divid, double sigma, double *ptprice, double *ptdelta)
{

int i;
double tk, u,du,dz,sig,z,p,mu,d1,d2,mean;
double CTtK, PTtK, Dlt, Plt;

int N=500;

p=1-2*(r-divid)/sigma/sigma;

  /*  Call Price */
CTtK=0;
du=12*sqrt(t)/N;
for (i=1;i<N;i++){
    u=du*(i-N/2.0);
    z=pseudo_stock*exp(sigma*u-p*sigma*sigma*t/2);
    mean=pseudo_stock*a(sigma,t,z/pseudo_stock)/t;
    sig = sqrt((1/t)*log(2*(b(sigma,t,z/pseudo_stock)/a(sigma,t,z/pseudo_stock)-1-z/pseudo_stock)/(sigma*sigma*a(sigma,t,z/pseudo_stock))));
 mu=-(1 - 2*log(t*mean)/sig/sig/t)*sig*sig*t/2;
      d1=(log(pseudo_stock*a(sigma,t,z/pseudo_stock)/pseudo_strike/t))/(sig*sqrt(t))+sig*sqrt(t)/2; 
    d2=d1-sig*sqrt(t);
    CTtK=CTtK+exp(-divid * t)*(12*sqrt(t)/N)*(exp(-(r-divid)*t)*((1/t)*exp(mu+sig*sig*t/2)*phi(d1)-pseudo_strike*phi(d2)))*exp(-u*u/(2*t))/sqrt(2*pi*t); 
 }
 
  /*  Delta for call option*/
Dlt=0.0;
dz=( exp(r-divid+sigma*sigma/2)+12*sqrt(( exp(sigma*sigma/2) - 1 )*exp(2*( r-divid ) +sigma*sigma)))/N;
for (i=1;i<N;i++){
z=dz*i;
   mean=a(sigma,t,z)/t;
   sig = sqrt((1/t)*log(2*(b(sigma,t,z)/a(sigma,t,z)-1-z)/(sigma*sigma*a(sigma,t,z))));
 if (IsFiniteNumber(sig)) {
  mu=-(1 - 2*log(t*mean)/sig/sig/t)*sig*sig*t/2;
    d1=(log(a(sigma,t,z)*pseudo_stock/pseudo_strike/t))/(sig*sqrt(t))+sig*sqrt(t)/2; 
    d2=d1-sig*sqrt(t);
    Dlt=Dlt+exp(-divid * t)*dz*pseudo_stock*(exp(-(r-divid)*t)*((1/t)*exp(mu+sig*sig*t/2)*(exp(-d1*d1/2)/sig/sqrt(2*pi)/sqrt(t)/pseudo_stock)+phi(d2)*pseudo_strike/pseudo_stock/pseudo_stock-pseudo_strike*(exp(-d2*d2/2)/sig/sqrt(2*pi)/sqrt(t)/pseudo_stock)/pseudo_stock))*exp(-pow(p*sigma*sigma*t/2+log(z),2)/2/sigma/sigma/t)/sigma/sqrt(2*pi*t)/z; 
        Dlt=Dlt+exp(-divid * t)*dz*(exp(-(r-divid)*t)*((1/t)*exp(mu+sig*sig*t/2)*phi(d1)-pseudo_strike*phi(d2)/pseudo_stock))*exp(-pow(p*sigma*sigma*t/2+log(z),2)/2/sigma/sigma/t)/sigma/sqrt(2*pi*t)/z; 
   };
 }
 
  /*  Put Price from Parity*/
  if (r == divid)
    PTtK = CTtK + pseudo_strike * exp(-r * t) - pseudo_stock * exp(-r * t);
  else
    PTtK = CTtK + pseudo_strike * exp(-r * t) - pseudo_stock * exp(-r * t) * (exp((r - divid) * t) - 1.) / (t * (r - divid));

  /*Delta for put option*/
  if (r == divid)
    Plt = Dlt - exp(-r * t);
  else
    Plt = Dlt - exp(-r * t) * (exp((r - divid) * t) - 1.0) / (t * (r - divid));

  /*Price*/
  if(call_or_put)
    *ptprice = CTtK;
  else
    *ptprice = PTtK;

  /*Delta */
  if(call_or_put)
    *ptdelta = Dlt;
  else
    *ptdelta = Plt;

  //   return  OK;

}


int main()
{
  int call_or_put;
  double stock,strike,t,r,divid,sigma,ptprice,ptdelta;

  call_or_put=0;
  stock=100;
  strike=90;
  t=1.6;
  r=0.05; // log(1.1);
  divid=0.03;
  sigma=0.2;

  Stratified_LogNormal_FixedAsian(call_or_put,stock,strike,t,r,divid,sigma,&ptprice,&ptdelta);

  printf("Asian option price=%f Delta=%f\n",ptprice,ptdelta);

}

