function [price,delta]=stratified_lognormal_fixedasian(call_or_put,stock,strike,t,r,divid,sigma)

    function p=p(sigma,t,z)
        p=exp(-(sigma^2*t/2+log(z))^2/2/sigma^2/t)/sqrt(2*pi*sigma^2*t);
end
    function q=q(sigma,t,z)
        q=exp(-(sigma^2*t+log(z))^2/2/sigma^2/t)/sqrt(2*pi*sigma^2*t);
end
    function a=a(sigma,t,z)
  a=(normcdf(log(z)/sigma/sqrt(t)+sigma*sqrt(t)/2.0)-normcdf(log(z)/sigma/sqrt(t)-sigma*sqrt(t)/2.0))/p(sigma,t,z)/sigma^2;
  
end
    function b=b(sigma,t,z)
        b=(normcdf(log(z)/sigma/sqrt(t)+sigma*sqrt(t))-normcdf(log(z)/sigma/sqrt(t)-sigma*sqrt(t)))/q(sigma,t,z)/sigma^2;
end
    function y=normcdf(x) 
        y = 1/2*erfc(-x/sqrt(2));
end

N=500;

% Call Price
CTtK=0;
du=12*sqrt(t)/N;
for i = 1:N 
    u=du*(i-N/2.0);
    z=stock*exp(sigma*u-(1-2*(r-divid)/sigma^2)*sigma^2*t/2);
    mean=stock*a(sigma,t,z/stock)/t;
    s = sqrt((1/t)*log(2*(b(sigma,t,z/stock)/a(sigma,t,z/stock)-1-z/stock)/(sigma^2*a(sigma,t,z/stock))));
    mu=-(1-2*log(t*mean)/s^2/t)*s^2*t/2;
    d1=(log(stock*a(sigma,t,z/stock)/strike/t))/(s*sqrt(t))+s*sqrt(t)/2; 
    d2=d1-s*sqrt(t);
    CTtK=CTtK+exp(-divid * t)*(12*sqrt(t)/N)*(exp(-(r-divid)*t)*((1/t)*exp(mu+s^2*t/2)*normcdf(d1)-strike*normcdf(d2)))*exp(-u^2/(2*t))/sqrt(2*pi*t); 
end
 
% Delta for call option
Dlt=0.0;
dz=( exp(r-divid+sigma^2/2)+12*sqrt(( exp(sigma^2/2) - 1 )*exp(2*( r-divid ) +sigma^2)))/N;

for i=1:N
    z=dz*i;
   mean=a(sigma,t,z)/t;
   s = sqrt((1/t)*log(2*(b(sigma,t,z)/a(sigma,t,z)-1-z)/(sigma^2*a(sigma,t,z))));
 if isfinite(s)
    mu=-(1-2*log(t*mean)/s^2/t)*s^2*t/2;
    d1=(log(a(sigma,t,z)*stock/strike/t))/(s*sqrt(t))+s*sqrt(t)/2; 
    d2=d1-s*sqrt(t);
    Dlt=Dlt+exp(-divid * t)*dz*stock*(exp(-(r-divid)*t)*((1/t)*exp(mu+s^2*t/2)*(exp(-d1^2/2)/s/sqrt(2*pi)/sqrt(t)/stock)+normcdf(d2)*strike/stock^2-strike*(exp(-d2^2/2)/s/sqrt(2*pi)/sqrt(t)/stock)/stock))*exp(-((1-2*(r-divid)/sigma^2)*sigma^2*t/2+log(z))^2/2/sigma^2/t)/sigma/sqrt(2*pi*t)/z; 
        Dlt=Dlt+exp(-divid * t)*dz*(exp(-(r-divid)*t)*((1/t)*exp(mu+s^2*t/2)*normcdf(d1)-strike*normcdf(d2)/stock))*exp(-((1-2*(r-divid)/sigma^2)*sigma^2*t/2+log(z))^2/2/sigma^2/t)/sigma/sqrt(2*pi*t)/z; 
 end
end

% Put Price from Parity
  if r == divid
    PTtK = CTtK + strike * exp(-r * t) - stock * exp(-r * t);
  else
    PTtK = CTtK + strike * exp(-r * t) - stock * exp(-r * t) * (exp((r - divid) * t) - 1.) / (t * (r - divid));
  end
  
% Delta for put option
  if r == divid
    Plt = Dlt - exp(-r * t);
  else
    Plt = Dlt - exp(-r * t) * (exp((r - divid) * t) - 1.0) / (t * (r - divid));
  end
  
% Price
  if call_or_put
    price = CTtK;
  else
    price = PTtK;
  end
  
% Delta

  if call_or_put
    delta = Dlt;
  else
    delta = Plt;
  end
end

% [price,delta]=stratified_lognormal_fixedasian(1,100,90,1.6,0.05,0.03,0.2)
